var ravalon = /(\w+)\[(avalonctrl)="(\S+)"\]/
var findNodes = function(str) {
    return DOC.querySelectorAll(str)
} 