avalon.unparam()
=========

**Description:** Convert a URL query string back to an object.

avalon.unparam( str )
-----------------------

**str**

Type: String

A string to convert.
