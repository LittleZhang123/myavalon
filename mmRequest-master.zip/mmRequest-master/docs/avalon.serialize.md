avalon.serialize()
=========

**Description:** Convert a set of form elements to a string.

avalon.serialize( element )
-----------------------

**element**

Type: Element

An element to convert.
