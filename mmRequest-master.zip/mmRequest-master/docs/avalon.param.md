avalon.param()
=========

**Description:** Convert an object to a URL query string.

avalon.param( obj )
-----------------------

**obj**

Type: PlainObject or Array

A plain object or An array to convert.
