mmAnimate
=========

avalon的三柱臣之一（ 路由，动画，AJAX）

<p>API完全与jQuery的保持一致</p>
<p>mmAnimate是基于单时间轴，使用setTimeout, requestAnimateFrame实现</p>
<p>mmAnimate.modern是基于单时间轴，使用requestAnimateFrame， CSS3 keyframe实现（只能运行IE10+，firefox 5+, chrome4+, safari4+, opera12+ ）</p>
<table width="90%">
    <tr> 
        <td>方法名</td>  <td>jQuery</td> <td>mmAniamte</td> <td>mmAniamte.modern</td>
    </tr>
    <tr> 
        <td>animate</td>  <td>支持</td>  <td>支持</td> <td>支持</td>
    </tr>
    <tr> 
        <td>stop</td>  <td>支持</td>  <td>支持</td> <td>支持</td>
    </tr>
    <tr> 
        <td>delay</td> <td>支持</td>  <td>支持</td> <td>支持</td>
    </tr>

    <tr> 
        <td>pause</td>  <td>不支持</td>  <td>支持</td> <td>支持</td>
    </tr>
    <tr> 
        <td>resume</td>  <td>不支持</td>  <td>支持</td> <td>支持</td>
    </tr>
    <tr> 
        <td>show</td> > <td>支持</td>  <td>支持</td> <td>支持</td>
    </tr>
    <tr> 
        <td>hide</td> > <td>支持</td>  <td>支持</td> <td>支持</td>
    </tr>
    <tr> 
        <td>toggle</td> > <td>支持</td>  <td>支持</td> <td>支持</td>
    </tr>
    <tr> 
        <td>slideDown</td>  > <td>支持</td>  <td>支持</td> <td>支持</td>
    </tr>
    <tr> 
        <td>slideUp</td> > <td>支持</td>  <td>支持</td> <td>支持</td>
    </tr>
    <tr> 
        <td>fadeIn</td>  > <td>支持</td>  <td>支持</td> <td>支持</td>
    </tr>
    <tr> 
        <td>fadeOut</td>  > <td>支持</td>  <td>支持</td> <td>支持</td>
    </tr>
    <tr> 
        <td>fadeToggle</td>  > <td>支持</td>  <td>支持</td> <td>支持</td>
    </tr>
    <tr> 
        <td>scrollTop与scrollLeft的动画处理</td>   <td>支持</td>  <td>支持</td> <td>支持</td>
    </tr>
</table>
